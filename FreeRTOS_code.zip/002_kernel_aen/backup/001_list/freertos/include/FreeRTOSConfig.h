/*----------------------------------------------------------------
 * author           : Aen
 * blog			    : https://aeneag.xyz
 * date             : 2021/12/13
 * FreeRTConfig.h   : FreeRTOS配置文件
 *----------------------------------------------------------------*/
#ifndef __FREEROTS_CONFIG_H
#define __FREEROTS_CONFIG_H

#define config_USE_16_BIT_TICKS		   0



#endif // !__FREEROTS_CONFIG_H
